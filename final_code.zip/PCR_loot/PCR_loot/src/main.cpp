#include <Arduino.h>
#include <UniversalTelegramBot.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include "DHT.h"
#include <string>
//#include <Arduino.h>

// Wifi network station credentials
#define WIFI_SSID "Xperia XA1 Plus_d1fb"
#define WIFI_PASSWORD "679ae961b1fc"

// Telegram BOT Token (Get from Botfather)
#define BOT_TOKEN "7040368229:AAEoQZNvMDUzaCTZ177E7fhVettplMd-dII"

#define PIN_MOTOR 27  // Управление насосом будет через пин 13 Arduino
#define DHTPIN 26     // Тот самый номер пина, о котором упоминалось выше
DHT dht(DHTPIN, DHT11); //Инициация датчика

//bool Pump_state = 0; // состояние насоса, 0 - выкл., 1 - вкл.
long sensor_check;  // для хранения времени считывания показаний с датчиков
long water_end;     // для хранения времени выключения насоса
long time_check;    // для хранения времени печати времени

int water_volume = 10 * 1000;   // объем (длительность полива) - 10 с
int water_period = 60 * 1000;   // период полива - 1 раз в минуту
int sensor_period = 30 * 1000;  // период полива - 2 раза в минуту
int time_period = 10 * 1000;    // частота вывода прошедшего времени - 1 раз в 10 с

const unsigned long BOT_MTBS = 1000; // mean time between scan messages

WiFiClientSecure secured_client;
UniversalTelegramBot bot(BOT_TOKEN, secured_client);
unsigned long bot_lasttime; // last time messages' scan has been done

void handleNewMessages(int numNewMessages);

void handleNewMessages(int numNewMessages)
{
  for (int i = 0; i < numNewMessages; i++)
  {
    String chat_id = bot.messages[i].chat_id;
    String text = bot.messages[i].text;

    String from_name = bot.messages[i].from_name;
    if (from_name == "")
      from_name = "Guest";

    if (text == "/start")
    {
      String welcome = "Welcome to the irrigation system, " + from_name + ".\n";
      welcome += "Here you can control some parameters.\n\n";
      bot.sendMessage(chat_id, welcome, "Markdown");
      String choose = "Please choose your action:\n current\_ temperature\n- current\_ humidity";
      bot.sendMessage(chat_id, choose, "Markdown");
    }
    else if (text == "current humidity")
    {
      float h = dht.readHumidity();
      String humidity = "Humidity is " + String(h);
      bot.sendMessage(chat_id, humidity, "Markdown");
    }
    else if (text == "current temperature")
    {
      float t = dht.readTemperature();
      String temperature = "Temperature is " + String(t);
      bot.sendMessage(chat_id, temperature, "Markdown");
    }
    else
    {
      bot.sendMessage(chat_id, "Incorrect input. Please use /start to begin.");
    }
  }
}

// Процедура, включающая насос на время, заданное в volume
void water() {
  digitalWrite(PIN_MOTOR, LOW);   // включаем насос
  delay(water_volume);            // на заданное время
  digitalWrite(PIN_MOTOR, HIGH);  // выключаем насос
}

void sensor() {
  delay(4000);                   // 2 секунды задержки
  float h = dht.readHumidity();  //Измеряем влажность
  delay(4000);
  float t = dht.readTemperature();  //Измеряем температуру

  Serial.print("Влажность: ");
  Serial.print(h);
  Serial.print(" %\t");
  Serial.print("Температура: ");
  Serial.print(t);
  Serial.println(" *C ");  //Вывод показателей на экран
}

void setup() {
  Serial.begin(115200);
  Serial.println();

  pinMode(PIN_MOTOR, OUTPUT);     // Настройка на выход пина для насоса
  digitalWrite(PIN_MOTOR, HIGH);  //  выключаем низкоуровневое реле
  dht.begin();
  // attempt to connect to Wifi network:
  Serial.print("Connecting to Wifi SSID ");
  Serial.print(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT); // Add root certificate for api.telegram.org
  
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print(".");
    delay(500);
  }
  Serial.print("\nWiFi connected. IP address: ");
  Serial.println(WiFi.localIP());

  Serial.print("Retrieving time: ");
  configTime(0, 0, "pool.ntp.org"); // get UTC time via NTP
  time_t now = time(nullptr);
  while (now < 24 * 3600)
  {
    Serial.print(".");
    delay(100);
    now = time(nullptr);
  }
  Serial.println(now);
  Serial.println("Starting Telegram Bot...");

}

 
void loop() {
    if (millis() - bot_lasttime > BOT_MTBS)
    {
      int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
      while (numNewMessages) 
      {
        handleNewMessages(numNewMessages);
        numNewMessages = bot.getUpdates(bot.last_message_received + 1);
      }
      bot_lasttime = millis();
    }

    if (sensor_check + sensor_period < millis()) {
      sensor();
      sensor_check = millis();
    }
    if (water_end + water_period < millis()) {
      water();
      water_end = millis();
    }
    if (time_check + time_period < millis()) {
      Serial.println(millis());
      time_check = millis();
    }


}